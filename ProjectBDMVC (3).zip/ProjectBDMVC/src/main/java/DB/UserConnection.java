
package DB;

public class UserConnection {
    private int indicador;
    public void confirmaUsuario(){
        
    }
    
    public int getIndicador(){
        return indicador;
    }
}
